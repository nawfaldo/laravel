@extends('template_backend.home')

@section('content')
    
<h1>Ini adalah catergory</h1>
@foreach ($category as $result)
    
    

@endforeach

@endsection