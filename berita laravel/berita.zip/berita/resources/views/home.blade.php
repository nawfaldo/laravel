@extends('template_backend.home')

@section('content')

<h1>Ini adalah content</h1>

@endsection