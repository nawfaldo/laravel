<?php $__env->startSection('content'); ?>

<h1>Ini adalah content</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template_backend.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/naufalfaqiihashshiddiq/.bitnami/stackman/machines/xampp/volumes/root/htdocs/berita/resources/views/home.blade.php ENDPATH**/ ?>